from pathlib import Path
from urllib.request import urlopen
from urllib.error import HTTPError, URLError
import time

downloads = Path.home() / "Downloads"
out_dir = downloads / "Mandragora_Project" / "05_references" / "H6H"
out_dir.mkdir(parents=True, exist_ok=True)

proteins = {
    "A0A6M6R352": "MoH6H.fasta",
    "P24397": "HnH6H.fasta",
    "Q9XJ43": "AbH6H.fasta",
    "Q6V0J1": "AtH6H.fasta",
    "A2IBI0": "AaH6H.fasta",
}

for accession, filename in proteins.items():
    url = f"https://rest.uniprot.org/uniprotkb/{accession}.fasta"
    output = out_dir / filename

    try:
        print(f"Downloading {accession}...")

        with urlopen(url, timeout=30) as response:
            fasta = response.read()

        output.write_bytes(fasta)

        print(f"Saved: {output}")

        # μικρή καθυστέρηση για να μην κάνουμε συνεχόμενα requests
        time.sleep(2)

    except HTTPError as e:
        print(f"HTTP error for {accession}: {e.code}")

    except URLError as e:
        print(f"Connection error for {accession}: {e.reason}")

print("\nFinished.")