from pathlib import Path
import pandas as pd
from Bio.Align import PairwiseAligner

# ---------------------------------------
# Paths
# ---------------------------------------

base = Path.home() / "Downloads" / "Mandragora_Project"
h6h_dir = base / "05_references" / "H6H"
tables_dir = base / "10_tables"

files = {
    "Mandragora officinarum": h6h_dir / "MoH6H.fasta",
    "Hyoscyamus niger": h6h_dir / "HnH6H.fasta",
    "Atropa belladonna": h6h_dir / "AbH6H.fasta",
    "Anisodus tanguticus": h6h_dir / "AtH6H.fasta",
    "Anisodus acutangulus": h6h_dir / "AaH6H.fasta",
}

# ---------------------------------------
# Read FASTA
# ---------------------------------------

def read_fasta(path):
    seq = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line or line.startswith(">"):
                continue

            seq.append(line)

    return "".join(seq)


sequences = {
    species: read_fasta(path)
    for species, path in files.items()
}

# ---------------------------------------
# Show lengths
# ---------------------------------------

print("\nProtein lengths:\n")

for species, seq in sequences.items():
    print(f"{species:25s} {len(seq)} aa")

# ---------------------------------------
# Pairwise aligner
# ---------------------------------------

aligner = PairwiseAligner()

aligner.mode = "global"

aligner.match_score = 2
aligner.mismatch_score = -1

aligner.open_gap_score = -10
aligner.extend_gap_score = -0.5

species_list = list(sequences.keys())

matrix = pd.DataFrame(
    index=species_list,
    columns=species_list,
    dtype=float
)

# ---------------------------------------
# Calculate alignment identity
# ---------------------------------------

def aligned_identity(seq1, seq2):

    alignment = aligner.align(seq1, seq2)[0]

    aligned_blocks_1 = alignment.aligned[0]
    aligned_blocks_2 = alignment.aligned[1]

    identical = 0
    aligned_positions = 0

    for block1, block2 in zip(aligned_blocks_1, aligned_blocks_2):

        start1, end1 = block1
        start2, end2 = block2

        fragment1 = seq1[start1:end1]
        fragment2 = seq2[start2:end2]

        for a, b in zip(fragment1, fragment2):

            aligned_positions += 1

            if a == b:
                identical += 1

    if aligned_positions == 0:
        return 0

    return identical / aligned_positions * 100


for sp1 in species_list:

    for sp2 in species_list:

        if sp1 == sp2:
            identity = 100.0

        else:
            identity = aligned_identity(
                sequences[sp1],
                sequences[sp2]
            )

        matrix.loc[sp1, sp2] = identity


print("\nAlignment-based pairwise identity:\n")
print(matrix.round(2))

output = tables_dir / "H6H_pairwise_identity_aligned.csv"

matrix.to_csv(output)

print("\nSaved:")
print(output)