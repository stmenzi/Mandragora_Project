from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Use the project’s original calculated CSV; no recalculation of the biological results.
base = Path.home() / 'Downloads' / 'Mandragora_Project'
input_file = base / '10_tables' / 'H6H_Mandragora_substitutions.csv'
output_dir = base / '11_figures'
output_dir.mkdir(parents=True, exist_ok=True)

raw = pd.read_csv(input_file)
required = ['Mandragora_position', 'Mandragora_residue', 'Consensus_residue', 'Conservation_other_species_percent']
missing = [c for c in required if c not in raw.columns]
if missing:
    raise ValueError(f'Missing CSV columns: {missing}. Available: {list(raw.columns)}')

df = raw.copy()
df['Mandragora_position'] = pd.to_numeric(df['Mandragora_position'], errors='raise')
df['Conservation_other_species_percent'] = pd.to_numeric(df['Conservation_other_species_percent'], errors='raise')
df['Substitution'] = (df['Consensus_residue'].astype(str) + df['Mandragora_position'].astype(int).astype(str) + df['Mandragora_residue'].astype(str))
df = df.sort_values('Mandragora_position').reset_index(drop=True)

highlight = ['Q119R', 'S214V', 'G220C', 'E270K', 'A288G']
selected = df[df['Substitution'].isin(highlight)]
other = df[~df['Substitution'].isin(highlight)]

fig, ax = plt.subplots(figsize=(10.2, 4.7))
ax.scatter(other['Mandragora_position'], other['Conservation_other_species_percent'],
           s=44, c='#337FA7', marker='o', edgecolors='white', linewidths=0.65,
           zorder=3, label='Other sequence differences')
ax.scatter(selected['Mandragora_position'], selected['Conservation_other_species_percent'],
           s=95, c='#E5922D', marker='D', edgecolors='#7A490E', linewidths=0.8,
           zorder=5, label='Highlighted candidates')

# Fixed label offsets leave separation between the neighbouring S214V and G220C.
placements = {
    'Q119R': ((-10, 20), 'right'),
    'S214V': ((-10, 22), 'right'),
    'G220C': ((-10, -23), 'right'),
    'E270K': ((10, -23), 'left'),
    'A288G': ((9, 20), 'left'),
}
for _, point in selected.iterrows():
    label = point['Substitution']
    offset, align = placements[label]
    ax.annotate(label,
                (point['Mandragora_position'], point['Conservation_other_species_percent']),
                xytext=offset, textcoords='offset points', ha=align, va='center',
                fontsize=10, fontweight='semibold', color='#854806',
                arrowprops=dict(arrowstyle='-', color='#95652E', lw=0.7),
                zorder=6)

ax.set(xlim=(-6, 352), ylim=(41, 114), xlabel='MoH6H amino-acid position',
       ylabel='Conservation among comparison proteins (%)')
ax.set_xticks(np.arange(0, 351, 50))
ax.set_yticks([50, 75, 100])
ax.grid(linestyle='--', linewidth=0.65, alpha=0.22)
ax.spines[['top', 'right']].set_visible(False)
ax.legend(loc='lower center', bbox_to_anchor=(0.5, 1.01), ncol=2,
          fontsize=9, frameon=False)
fig.tight_layout(pad=1.2)

image_path = output_dir / 'Figure_H6H_Mutation_Conservation_Map.png'
fig.savefig(image_path, dpi=300, bbox_inches='tight', facecolor='white')
fig.savefig(output_dir / 'Figure_H6H_Mutation_Conservation_Map.pdf', bbox_inches='tight', facecolor='white')
plt.show()

# The full index is kept in a separate supplementary file instead of crowded inside the figure.
supp_path = base / '10_tables' / 'Supplementary_Table_S1_MoH6H_Differences.csv'
df[['Substitution', 'Mandragora_position', 'Conservation_other_species_percent']].to_csv(supp_path, index=False)
print('Figure:', image_path)
print('Supplementary Table S1:', supp_path)
print('Number of differences:', len(df))
