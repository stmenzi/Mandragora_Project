from pathlib import Path
from collections import Counter
import pandas as pd

# ----------------------------------------
# Paths
# ----------------------------------------

base = Path.home() / "Downloads" / "Mandragora_Project"

alignment_file = (
    base
    / "07_alignments"
    / "H6H_aligned.fasta.aln-fasta"
)

output_file = (
    base
    / "10_tables"
    / "H6H_Mandragora_substitutions.csv"
)

# ----------------------------------------
# Read aligned FASTA
# ----------------------------------------

def read_fasta_alignment(path):
    sequences = {}
    current_name = None
    current_sequence = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith(">"):
                if current_name is not None:
                    sequences[current_name] = "".join(current_sequence)

                current_name = line[1:]
                current_sequence = []

            else:
                current_sequence.append(line)

    if current_name is not None:
        sequences[current_name] = "".join(current_sequence)

    return sequences


# ----------------------------------------
# Load alignment
# ----------------------------------------

sequences = read_fasta_alignment(alignment_file)

print("\nSequences found:\n")

for name, seq in sequences.items():
    print(name)
    print("Aligned length:", len(seq))
    print()


# ----------------------------------------
# Find Mandragora sequence automatically
# ----------------------------------------

mandragora_name = None

for name in sequences:
    name_lower = name.lower()

    if "mandragora" in name_lower or "a0a6m6r352" in name_lower:
        mandragora_name = name
        break

if mandragora_name is None:
    raise ValueError("Mandragora officinarum sequence was not found.")

print("\nMandragora sequence identified as:")
print(mandragora_name)

mandragora_seq = sequences[mandragora_name]

other_sequences = {
    name: seq
    for name, seq in sequences.items()
    if name != mandragora_name
}

# ----------------------------------------
# Detect Mandragora substitutions
# ----------------------------------------

results = []

mandragora_position = 0

for alignment_position in range(len(mandragora_seq)):

    mo_residue = mandragora_seq[alignment_position]

    # Skip alignment positions where Mandragora has a gap
    if mo_residue == "-":
        continue

    mandragora_position += 1

    other_residues = []

    for seq in other_sequences.values():
        residue = seq[alignment_position]

        if residue != "-":
            other_residues.append(residue)

    if not other_residues:
        continue

    counts = Counter(other_residues)

    consensus_residue, consensus_count = counts.most_common(1)[0]

    conservation_percent = (
        consensus_count / len(other_residues)
    ) * 100

    # Only keep positions where Mandragora differs from consensus
    if mo_residue != consensus_residue:

        results.append({
            "Alignment_position": alignment_position + 1,
            "Mandragora_position": mandragora_position,
            "Mandragora_residue": mo_residue,
            "Consensus_residue": consensus_residue,
            "Conservation_other_species_percent":
                conservation_percent,
            "Other_species_residues":
                "".join(other_residues)
        })


# ----------------------------------------
# Create table
# ----------------------------------------

df = pd.DataFrame(results)

if len(df) == 0:
    print("\nNo substitutions found.")

else:
    df = df.sort_values(
        by="Conservation_other_species_percent",
        ascending=False
    )

    df.to_csv(
        output_file,
        index=False
    )

    print("\nNumber of Mandragora substitutions:")
    print(len(df))

    print("\nTop substitutions:\n")

    print(
        df.head(20).to_string(index=False)
    )

    print("\nSaved file:")
    print(output_file)