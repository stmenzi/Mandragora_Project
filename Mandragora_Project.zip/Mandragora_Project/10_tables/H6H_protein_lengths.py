from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# --------------------------------------------------
# Paths
# --------------------------------------------------

base = Path.home() / "Downloads" / "Mandragora_Project"
h6h_dir = base / "05_references" / "H6H"
tables_dir = base / "10_tables"
figures_dir = base / "11_figures"

tables_dir.mkdir(parents=True, exist_ok=True)
figures_dir.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------
# FASTA files
# --------------------------------------------------

files = {
    "Mandragora officinarum": h6h_dir / "MoH6H.fasta",
    "Hyoscyamus niger": h6h_dir / "HnH6H.fasta",
    "Atropa belladonna": h6h_dir / "AbH6H.fasta",
    "Anisodus tanguticus": h6h_dir / "AtH6H.fasta",
    "Anisodus acutangulus": h6h_dir / "AaH6H.fasta",
}

# --------------------------------------------------
# Simple FASTA reader
# --------------------------------------------------

def read_fasta(path):
    sequence = []

    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()

            if not line:
                continue

            if line.startswith(">"):
                continue

            sequence.append(line)

    return "".join(sequence)

# --------------------------------------------------
# Read sequences
# --------------------------------------------------

sequences = {}

for species, path in files.items():

    if not path.exists():
        print("Missing file:", path)
        continue

    seq = read_fasta(path)
    sequences[species] = seq

    print(species)
    print("Length:", len(seq))
    print()

# --------------------------------------------------
# Save protein lengths
# --------------------------------------------------

length_df = pd.DataFrame({
    "Species": list(sequences.keys()),
    "Protein_length_aa": [len(seq) for seq in sequences.values()]
})

length_output = tables_dir / "H6H_protein_lengths.csv"
length_df.to_csv(length_output, index=False)

print("Protein lengths saved to:")
print(length_output)

# --------------------------------------------------
# Pairwise identity
# NOTE:
# This first version compares positions directly.
# Proper alignment-based identity comes next with MAFFT.
# --------------------------------------------------

species = list(sequences.keys())

identity_matrix = pd.DataFrame(
    index=species,
    columns=species,
    dtype=float
)

for sp1 in species:
    for sp2 in species:

        seq1 = sequences[sp1]
        seq2 = sequences[sp2]

        min_len = min(len(seq1), len(seq2))

        identical = sum(
            a == b
            for a, b in zip(seq1[:min_len], seq2[:min_len])
        )

        identity = identical / min_len * 100

        identity_matrix.loc[sp1, sp2] = identity

identity_output = tables_dir / "H6H_pairwise_identity_preliminary.csv"
identity_matrix.to_csv(identity_output)

print("\nPreliminary pairwise identity matrix:")
print(identity_matrix.round(2))

# --------------------------------------------------
# Figure: protein lengths
# --------------------------------------------------

fig, ax = plt.subplots(figsize=(9, 5))

ax.bar(
    length_df["Species"],
    length_df["Protein_length_aa"]
)

ax.set_ylabel("Protein length (amino acids)")
ax.set_title("H6H protein lengths across Solanaceae")

ax.tick_params(axis="x", rotation=35)

for i, value in enumerate(length_df["Protein_length_aa"]):
    ax.text(
        i,
        value,
        str(value),
        ha="center",
        va="bottom"
    )

fig.tight_layout()

figure_output = figures_dir / "Figure_H6H_Protein_Lengths.png"

plt.savefig(
    figure_output,
    dpi=600,
    bbox_inches="tight"
)

plt.show()

print("\nFigure saved to:")
print(figure_output)