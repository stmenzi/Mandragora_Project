from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# --------------------------------------------------
# Paths
# --------------------------------------------------

base = Path.home() / "Downloads" / "Mandragora_Project"

input_file = (
    base
    / "10_tables"
    / "H6H_Mandragora_substitutions.csv"
)

output_table = (
    base
    / "10_tables"
    / "H6H_mutation_ranking_v2.csv"
)

output_figure = (
    base
    / "11_figures"
    / "Figure_H6H_Top10_Mutation_Ranking_v2.png"
)

# --------------------------------------------------
# Load data
# --------------------------------------------------

df = pd.read_csv(input_file)

df["Mutation"] = (
    df["Consensus_residue"]
    + df["Mandragora_position"].astype(str)
    + df["Mandragora_residue"]
)

# --------------------------------------------------
# Known functional H6H residues
# Based on structural studies
# --------------------------------------------------

functional_sites = {
    116: "substrate binding",
    217: "metal binding",
    219: "metal binding",
    274: "metal binding",
    284: "2-oxoglutarate binding",
    286: "2-oxoglutarate binding",
    326: "substrate binding",
}

# --------------------------------------------------
# Amino-acid physicochemical categories
# --------------------------------------------------

hydrophobic = set("AVLIMFWY")
polar = set("STNQ")
positive = set("KRH")
negative = set("DE")

def severity_score(old, new):

    if old == new:
        return 0

    # Glycine, proline and cysteine deserve special handling
    if old == "G" or new == "G":
        return 3

    if old == "P" or new == "P":
        return 3

    if old == "C" or new == "C":
        return 3

    # Charge reversal
    if (
        (old in positive and new in negative)
        or
        (old in negative and new in positive)
    ):
        return 4

    # Charged <-> uncharged
    if (
        old in positive
        or old in negative
        or new in positive
        or new in negative
    ):
        return 3

    # Same broad class
    groups = [hydrophobic, polar]

    for group in groups:
        if old in group and new in group:
            return 1

    return 2

# --------------------------------------------------
# Conservation score
# --------------------------------------------------

def conservation_score(percent):

    if percent == 100:
        return 5

    if percent >= 75:
        return 4

    if percent >= 50:
        return 3

    if percent >= 25:
        return 2

    return 1

# --------------------------------------------------
# Functional-site proximity
# --------------------------------------------------

def nearest_functional_site(position):

    distances = {
        site: abs(position - site)
        for site in functional_sites
    }

    nearest_site = min(
        distances,
        key=distances.get
    )

    distance = distances[nearest_site]

    return nearest_site, distance


def functional_proximity_score(position):

    nearest_site, distance = nearest_functional_site(position)

    if distance == 0:
        return 6

    if distance == 1:
        return 5

    if distance <= 3:
        return 4

    if distance <= 5:
        return 3

    if distance <= 10:
        return 2

    return 0

# --------------------------------------------------
# Calculate scores
# --------------------------------------------------

df["Conservation_score"] = df[
    "Conservation_other_species_percent"
].apply(conservation_score)

df["Severity_score"] = df.apply(
    lambda row: severity_score(
        row["Consensus_residue"],
        row["Mandragora_residue"]
    ),
    axis=1
)

df["Functional_proximity_score"] = df[
    "Mandragora_position"
].apply(functional_proximity_score)

nearest_sites = []

distances = []

site_functions = []

for position in df["Mandragora_position"]:

    site, distance = nearest_functional_site(position)

    nearest_sites.append(site)
    distances.append(distance)
    site_functions.append(
        functional_sites[site]
    )

df["Nearest_functional_site"] = nearest_sites
df["Distance_to_functional_site"] = distances
df["Nearest_site_function"] = site_functions

# --------------------------------------------------
# Total priority score
# --------------------------------------------------

df["Priority_score"] = (
    df["Conservation_score"] * 2
    + df["Severity_score"] * 2
    + df["Functional_proximity_score"] * 3
)

# --------------------------------------------------
# Priority label
# --------------------------------------------------

def priority_label(score):

    if score >= 28:
        return "High"

    if score >= 20:
        return "Medium"

    return "Low"

df["Priority"] = df[
    "Priority_score"
].apply(priority_label)

# --------------------------------------------------
# Sort and save
# --------------------------------------------------

df = df.sort_values(
    "Priority_score",
    ascending=False
)

df.to_csv(
    output_table,
    index=False
)

# --------------------------------------------------
# Print top candidates
# --------------------------------------------------

columns = [
    "Mutation",
    "Conservation_other_species_percent",
    "Severity_score",
    "Nearest_functional_site",
    "Distance_to_functional_site",
    "Nearest_site_function",
    "Priority_score",
    "Priority"
]

print("\nTop ranked substitutions:\n")

print(
    df[columns]
    .head(15)
    .to_string(index=False)
)

print("\nSaved:")
print(output_table)

# --------------------------------------------------
# Figure
# --------------------------------------------------

top10 = df.head(10).copy()

top10 = top10.sort_values(
    "Priority_score",
    ascending=True
)

fig, ax = plt.subplots(figsize=(10, 6))

bars = ax.barh(
    top10["Mutation"],
    top10["Priority_score"]
)

ax.set_xlabel("Functional-priority score")
ax.set_ylabel("Amino-acid substitution")

ax.set_title(
    "Priority ranking of H6H substitutions in "
    "Mandragora officinarum"
)

for bar, score in zip(
    bars,
    top10["Priority_score"]
):

    ax.text(
        score + 0.2,
        bar.get_y() + bar.get_height() / 2,
        f"{score:.0f}",
        va="center"
    )

fig.tight_layout()

plt.savefig(
    output_figure,
    dpi=600,
    bbox_inches="tight"
)

plt.show()

print("\nFigure saved:")
print(output_figure)