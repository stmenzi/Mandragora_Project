from pathlib import Path

# Βρίσκει αυτόματα τον φάκελο Downloads του χρήστη
downloads = Path.home() / "Downloads"

# Κεντρικός φάκελος project
base = downloads / "Mandragora_Project"

# Υποφάκελοι που θέλουμε να δημιουργηθούν
folders = [
    "00_raw",
    "01_fastp",
    "02_trinity",
    "03_busco",
    "04_proteins",
    "05_references/H6H",
    "06_blast",
    "07_alignments",
    "08_phylogeny",
    "09_structures",
    "10_tables",
    "11_figures",
    "scripts",
]

# Δημιουργία φακέλων
for folder in folders:
    path = base / folder
    path.mkdir(parents=True, exist_ok=True)

print("Έτοιμο!")
print("Το project δημιουργήθηκε εδώ:")
print(base)