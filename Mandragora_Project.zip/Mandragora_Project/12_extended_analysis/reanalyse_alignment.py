from pathlib import Path
from Bio import AlignIO
import csv
from collections import Counter
ROOT=Path(__file__).resolve().parent
aln=AlignIO.read(ROOT/'H6H_aligned.fasta.aln-fasta','fasta')
seqs=[str(r.seq) for r in aln]
names=[r.id for r in aln]
i_mo=next(i for i,n in enumerate(names) if 'A0A6M6R352' in n)
mo=seqs[i_mo]; indexes=[i for i in range(len(seqs)) if i!=i_mo]
rows=[]; pos=0
for col,char in enumerate(mo):
 if char=='-': continue
 pos+=1
 vals=[seqs[i][col] for i in indexes]
 non=[v for v in vals if v!='-']
 if not non:continue
 consensus=Counter(non).most_common(1)[0][0]
 if char==consensus:continue
 unanimous=len(non)==4 and len(set(non))==1
 supported=[]
 for hold in range(4):
  other=[v for k,v in enumerate(vals) if k!=hold and v!='-']
  if not other: supported.append(False);continue
  maxima=max(Counter(other).values())
  winners=[v for v,num in Counter(other).items() if num==maxima]
  supported.append(len(winners)==1 and winners[0]!=char)
 rows.append(dict(position=pos,original_label=f'{consensus}{pos}{char}',reference_residues=''.join(vals),unanimous_four=unanimous,leave_one_out_support=sum(supported), all_four_leave_one_out=all(supported), stable_non_tie=sum(supported)==4))
with open(ROOT/'verified_consensus_loo.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print('Original differences',len(rows),'unanimous',sum(x['unanimous_four'] for x in rows))
print('LOO support distribution',Counter(r['leave_one_out_support'] for r in rows))
print('All-four LOO',sum(r['all_four_leave_one_out'] for r in rows))
for p in [119,214,220,270,288]:
 r=next((r for r in rows if r['position']==p),None);print(p,r)
from Bio.Align import substitution_matrices
blosum=substitution_matrices.load('BLOSUM62')
for r in rows:
 lab=r['original_label'];a=lab[0];b=lab[-1]
 r['blosum62_pair_score']=float(blosum[a,b])
with open(ROOT/'verified_consensus_loo_blosum62.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
print('BLOSUM examples')
for p in [119,214,220,270,288]:
 r=next(x for x in rows if x['position']==p)
 print(r['original_label'],r['blosum62_pair_score'])
